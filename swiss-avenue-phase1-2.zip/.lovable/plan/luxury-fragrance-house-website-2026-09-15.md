# Luxury fragrance house website

## Scope
- Replace the starter page with one polished, mobile-first scrolling website.
- Use the supplied dark ink, warm ivory, antique brass, and bottle-green art direction.
- Create an original serif wordmark and minimal bottle monogram used throughout.
- Add a 5–6 second, once-per-session intro with skip and reduced-motion handling.
- Build fixed navigation, hero, quote marquee, collection, sourcing, retail/wholesale, story, process, testimonials, enquiry, and footer sections.
- Add compact WhatsApp and call actions and wire all enquiry paths to contact links.
- Use generated perfume photography so the collection and storytelling are production-quality rather than placeholders.
- Add responsive behavior, keyboard focus states, semantic structure, alt text, and page metadata.

## Content assumptions
- Because final business details were not supplied, use `[BRAND NAME]`, `[PHONE NUMBER]`, and `[EMAIL]` visibly and centrally so they cannot be mistaken for real information.
- Use a curated fictional launch collection with sample pricing, clearly noted in the final handoff as content to replace before publishing.
- Omit a street address and real social URLs rather than inventing them.

## Technical details
- Keep the experience at `/` with anchor navigation as explicitly requested.
- Store intro completion in session storage and bypass it for `prefers-reduced-motion`.
- Submit the enquiry form into a pre-filled WhatsApp message, with call and email alternatives.
- Define all colors, fonts, effects, and animation utilities as semantic tokens in the global design system.
- Verify the finished page at desktop and mobile widths, including the intro and form interaction.
