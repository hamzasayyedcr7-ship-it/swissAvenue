# Swiss Avenue Phase 1 Storefront

## Goal
Turn the existing Swiss Avenue site into a polished, frontend-only perfume storefront while preserving the official logo, owner/contact details, useful editorial content, and intro experience. The new storefront interface will use sky blue and white; the supplied logo remains unchanged as the brand asset.

## What will be built

### Shared storefront experience
- Introduce a responsive e-commerce header with the Swiss Avenue logo and links for Home, Shop, Search, Wishlist, Cart, and a clearly inactive Login/Profile placeholder.
- Keep the existing homepage storytelling sections and business details, restyling only what is necessary to make the site consistently sky blue and white.
- Retain the existing intro behavior and official logo, adapting only its surrounding colors to the new theme.
- Show live wishlist and cart item counts in the navigation.

### Product catalogue
- Add 54 structured sample perfumes across categories such as Eau de Parfum, Eau de Toilette, Oud, Attar, Floral, Fresh, Woody, and Unisex.
- Create a premium shop grid with realistic product photography, product name, type, price, wishlist control, Add to Cart, and Buy Now.
- Add a prominent name search, category filter, price-range control, result count, and sorting for newest, price ascending, and price descending.
- Include clear no-results and reset-filter states.

### Product details
- Add a dedicated product route for every sample perfume.
- Present a large product image, name, price, type, notes, professional description, quantity control, wishlist, Add to Cart, and Buy Now.
- Keep navigation back to the shop simple and responsive.

### Cart and wishlist
- Add a cart page plus an accessible cart side panel from the header.
- Support add, remove, quantity increase/decrease, item count, subtotal, and empty-cart state.
- Add a dedicated wishlist page with remove and Move to Cart actions.
- Make Buy Now add the selected item and open the cart; no checkout or payment flow will be created.

### Visual direction
- Replace the current ink/ivory/brass interface palette with semantic sky-blue and white tokens, using deeper blue only for readable text and controls.
- Preserve elegant serif display typography and refined sans-serif body typography.
- Use crisp borders, restrained shadows, spacious grids, subtle motion, and premium image presentation without excessive gradients or clutter.
- Verify layouts on mobile, tablet, and desktop.

## Technical details
- Add separate TanStack routes for `/shop`, `/products/$productId`, `/wishlist`, and `/cart`, each with unique metadata.
- Keep catalogue data in a typed frontend data module and filtering/sorting in reusable utilities.
- Add a shared React storefront provider for cart and wishlist state, persisted locally in the browser only; no Cloud, accounts, API, database, or server functions.
- Build reusable storefront header, product card/grid, filters, cart panel, empty state, and quantity controls using existing design-system controls.
- Store generated product imagery as bundled project assets and reuse coordinated images only where visually appropriate.

## Boundaries
- No authentication, payment gateway, checkout, admin dashboard, WhatsApp automation, or database work.
- No removal of the official Swiss Avenue logo, owner information, contact details, or useful existing editorial content.
- No invented claim that sample products are currently available; catalogue content remains clearly demonstrative until replaced with final inventory.

## Validation
- Test search, each filter, sorting, product navigation, cart quantities/removal/totals, wishlist add/remove/move-to-cart, and empty states.
- Check keyboard focus, accessible labels, image alt text, route metadata, mobile/tablet/desktop layouts, and browser console errors.
