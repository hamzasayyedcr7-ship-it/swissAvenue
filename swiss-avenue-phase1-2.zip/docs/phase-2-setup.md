# Phase 2 setup — database + authentication

## 1. Create a Supabase project

1. [supabase.com](https://supabase.com) → New project. Pick a region close to your customers (e.g. Mumbai/ap-south-1).
2. Once it's provisioned, go to **Project Settings → API** and note:
   - **Project URL** → `VITE_SUPABASE_URL`
   - **anon public key** → `VITE_SUPABASE_ANON_KEY`
   - **service_role key** → `SUPABASE_SERVICE_ROLE_KEY` (keep this secret — never commit it, never prefix it with `VITE_`)

## 2. Run the schema

Open **SQL Editor** in the Supabase dashboard, paste the contents of
`supabase/migrations/0001_init.sql`, and run it. (Alternatively, if you use
the Supabase CLI locally: `supabase link` then `supabase db push`.)

This creates every table, the `is_admin()` helper, the new-user trigger that
auto-creates a `profiles` row, and all Row Level Security policies.

## 3. Configure environment variables

```bash
cp .env.example .env
```

Fill in the three Supabase values from step 1. Leave the Razorpay lines
commented out — those arrive in Phase 3.

## 4. Install the new dependency and run

```bash
npm install
npm run dev
```

`npm install` picks up `@supabase/supabase-js`, which was added to
`package.json` in this phase. `npm run dev` (or `build`) is also what
regenerates `src/routeTree.gen.ts` to include the new routes — don't hand-edit
that file.

## 5. Create your first account, then promote it to admin

1. Visit `/signup` and create an account with your real email.
2. If your Supabase project has email confirmation on (the default), check
   your inbox and confirm before logging in.
3. Back in the SQL Editor, run:

   ```sql
   update public.profiles set role = 'admin'
   where id = (select id from auth.users where email = 'you@example.com');
   ```

There's no admin dashboard yet (that's next), but this is the account the
admin login will use once it exists.

## What's real vs. what's still a placeholder

- **Real**: sign up, login, logout, forgot/reset password, profile row,
  saved addresses (all backed by Supabase, protected by RLS).
- **Placeholder**: the shop still reads products from the static
  `src/lib/products.ts` file, not the `products` table — the schema is ready,
  but the storefront hasn't been switched over yet. Cart/wishlist also still
  live in `localStorage` rather than `cart_items`/`wishlist_items`. Order
  history on the account page is empty because checkout (Phase 3) doesn't
  exist yet.
