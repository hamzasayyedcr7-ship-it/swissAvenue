import { Link } from "@tanstack/react-router";
import { BrandLogo } from "./site-header";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-secondary px-5 py-12 sm:px-8 lg:px-10">
      <div className="mx-auto grid max-w-[1480px] gap-10 md:grid-cols-[1fr_auto_auto] md:items-end">
        <div><BrandLogo /><p className="mt-4 max-w-sm text-sm leading-6 text-muted-foreground">Imported fragrance for private collections and discerning trade partners.</p></div>
        <nav className="grid grid-cols-2 gap-x-10 gap-y-2 text-sm" aria-label="Footer navigation"><Link to="/">Home</Link><Link to="/shop">Shop</Link><Link to="/wishlist">Wishlist</Link><Link to="/cart">Cart</Link></nav>
        <div className="text-sm leading-7 text-muted-foreground md:text-right"><p>9028905454</p><a href="mailto:Maazkazi8000@gmail.com">Maazkazi8000@gmail.com</a><p>Owned by Maaz Kazi</p></div>
      </div>
      <div className="mx-auto mt-10 flex max-w-[1480px] flex-wrap justify-between gap-3 border-t border-border pt-5 text-xs text-muted-foreground"><span>© 2026 Swiss Avenue. All rights reserved.</span><span>Phase 1 storefront preview</span></div>
    </footer>
  );
}