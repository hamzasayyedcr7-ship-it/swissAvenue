import { Link } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";

export function EmptyState({ title, copy }: { title: string; copy: string }) {
  return (
    <div className="grid min-h-80 place-items-center border border-border bg-card px-6 text-center">
      <div>
        <ShoppingBag className="mx-auto size-8 text-primary" />
        <h2 className="mt-5 font-display text-4xl text-foreground">{title}</h2>
        <p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-muted-foreground">{copy}</p>
        <Button asChild className="mt-7 rounded-none"><Link to="/shop">Explore fragrances</Link></Button>
      </div>
    </div>
  );
}