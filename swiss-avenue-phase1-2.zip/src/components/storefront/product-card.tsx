import { Link } from "@tanstack/react-router";
import { Heart, ShoppingBag, Star } from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { formatPrice, type Product } from "@/lib/products";
import { useStorefront } from "@/lib/storefront";

export function ProductCard({ product }: { product: Product }) {
  const { wishlist, toggleWishlist, addToCart, setCartOpen } = useStorefront();
  const saved = wishlist.includes(product.id);
  const outOfStock = product.stock <= 0;
  const lowStock = !outOfStock && product.stock <= 5;

  return (
    <article className="store-product group flex min-w-0 flex-col bg-card">
      <div className="relative overflow-hidden bg-secondary">
        <Link to="/products/$productId" params={{ productId: product.id }} aria-label={`View ${product.name}`}>
          <img src={product.image} alt={`${product.name} perfume bottle`} width={1024} height={1280} loading="lazy" className={cn("aspect-[4/5] h-auto w-full object-cover transition-transform duration-700 group-hover:scale-[1.025]", outOfStock && "opacity-60 grayscale-[0.3]")} />
        </Link>
        {product.discountPercent > 0 && <span className="absolute left-3 top-3 bg-primary px-2 py-1 text-[0.6rem] font-semibold tracking-[0.08em] text-primary-foreground">-{product.discountPercent}%</span>}
        {outOfStock && <span className="absolute left-3 bottom-3 bg-foreground/90 px-2 py-1 text-[0.6rem] font-semibold tracking-[0.08em] text-background">Out of stock</span>}
        <Button type="button" variant="outline" size="icon" onClick={() => toggleWishlist(product.id)} aria-label={saved ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`} className={cn("absolute right-3 top-3 rounded-full border-primary/20 bg-background/90 shadow-sm backdrop-blur", saved && "bg-primary text-primary-foreground hover:bg-primary/90")}>
          <Heart className={saved ? "fill-current" : ""} />
        </Button>
      </div>
      <div className="flex flex-1 flex-col p-4 sm:p-5">
        <p className="text-xs text-muted-foreground">{product.type} · {product.size}</p>
        <Link to="/products/$productId" params={{ productId: product.id }} className="mt-2 font-display text-2xl leading-none text-foreground hover:text-primary">
          {product.name}
        </Link>
        <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
          <Star className="size-3.5 fill-primary text-primary" />
          <span className="font-medium text-foreground">{product.rating}</span>
          <span>({product.reviewCount})</span>
        </div>
        <p className="mt-2 line-clamp-1 text-xs text-muted-foreground">{product.notes}</p>
        <div className="mt-4 flex items-baseline gap-2">
          <p className="text-sm font-semibold text-foreground">{formatPrice(product.price)}</p>
          {product.discountPercent > 0 && <p className="text-xs text-muted-foreground line-through">{formatPrice(product.mrp)}</p>}
        </div>
        {lowStock && <p className="mt-1 text-xs text-amber-600">Only {product.stock} left</p>}
        <div className="mt-auto grid grid-cols-2 gap-2 pt-5">
          {outOfStock ? (
            <Button type="button" variant="outline" disabled className="col-span-2 h-10 rounded-none">Out of stock</Button>
          ) : (
            <>
              <Button type="button" variant="outline" className="h-10 rounded-none" onClick={() => addToCart(product.id)}><ShoppingBag /> Add to cart</Button>
              <Button type="button" className="h-10 rounded-none" onClick={() => { addToCart(product.id); setCartOpen(true); }}>Buy now</Button>
            </>
          )}
        </div>
      </div>
    </article>
  );
}