import { Link } from "@tanstack/react-router";
import { Heart, Menu, Search, ShoppingBag, UserRound, X } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import swissAvenueLogo from "@/assets/swiss-avenue-logo.png.asset.json";
import { useAuth } from "@/lib/auth";
import { useStorefront } from "@/lib/storefront";
import { CartContent } from "./cart-content";

export function BrandLogo({ large = false }: { large?: boolean }) {
  return <img src={swissAvenueLogo.url} alt="Swiss Avenue" width={1547} height={753} className={large ? "h-auto w-52" : "h-auto w-28 sm:w-32"} />;
}

export function SiteHeader() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { cartCount, wishlist, cartOpen, setCartOpen } = useStorefront();
  const { user, configured } = useAuth();
  const nav = [{ label: "Home", to: "/" }, { label: "Shop", to: "/shop" }] as const;

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-xl">
        <div className="mx-auto flex h-20 max-w-[1480px] items-center justify-between gap-4 px-5 sm:px-8 lg:px-10">
          <Link to="/" aria-label="Swiss Avenue home"><BrandLogo /></Link>
          <nav className="hidden items-center gap-8 lg:flex" aria-label="Store navigation">
            {nav.map((item) => <Link key={item.to} to={item.to} className="text-sm text-muted-foreground transition-colors hover:text-primary" activeProps={{ className: "text-primary" }} activeOptions={{ exact: item.to === "/" }}>{item.label}</Link>)}
            <Link to="/shop" search={{ focus: "search" }} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary"><Search className="size-4" /> Search</Link>
          </nav>
          <div className="flex items-center gap-1">
            <Button asChild variant="ghost" size="icon" className="relative rounded-full"><Link to="/wishlist" aria-label={`Wishlist, ${wishlist.length} items`}><Heart />{wishlist.length > 0 && <Count value={wishlist.length} />}</Link></Button>
            <Button type="button" variant="ghost" size="icon" className="relative rounded-full" onClick={() => setCartOpen(true)} aria-label={`Cart, ${cartCount} items`}><ShoppingBag />{cartCount > 0 && <Count value={cartCount} />}</Button>
            <Button asChild variant="ghost" size="icon" className="hidden rounded-full sm:inline-flex" disabled={!configured}>
              <Link to={user ? "/account" : "/login"} aria-label={user ? "My account" : "Log in"}><UserRound /></Link>
            </Button>
            <Button type="button" variant="ghost" size="icon" className="rounded-full lg:hidden" onClick={() => setMenuOpen((open) => !open)} aria-expanded={menuOpen} aria-label="Toggle menu">{menuOpen ? <X /> : <Menu />}</Button>
          </div>
        </div>
        {menuOpen && <nav className="border-t border-border bg-background px-5 py-5 lg:hidden" aria-label="Mobile store navigation">
          {[...nav, { label: "Search", to: "/shop" as const }, { label: "Wishlist", to: "/wishlist" as const }, { label: "Cart", to: "/cart" as const }, { label: user ? "Account" : "Log in", to: (user ? "/account" : "/login") as const }].map((item) => <Link key={`${item.label}-${item.to}`} to={item.to} onClick={() => setMenuOpen(false)} className="block border-b border-border py-3 font-display text-2xl text-foreground">{item.label}</Link>)}
        </nav>}
      </header>
      <Sheet open={cartOpen} onOpenChange={setCartOpen}>
        <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-md">
          <SheetHeader><SheetTitle className="font-display text-3xl font-normal">Your cart</SheetTitle><SheetDescription>{cartCount} {cartCount === 1 ? "item" : "items"} selected</SheetDescription></SheetHeader>
          <div className="mt-6"><CartContent compact /></div>
        </SheetContent>
      </Sheet>
    </>
  );
}

function Count({ value }: { value: number }) {
  return <span className="absolute -right-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-primary text-[9px] text-primary-foreground">{value > 99 ? "99" : value}</span>;
}