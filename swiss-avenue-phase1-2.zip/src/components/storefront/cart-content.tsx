import { Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { formatPrice, getProduct } from "@/lib/products";
import { useStorefront } from "@/lib/storefront";
import { EmptyState } from "./empty-state";

export function CartContent({ compact = false }: { compact?: boolean }) {
  const { cart, removeFromCart, setQuantity, setCartOpen } = useStorefront();
  const lines = cart.flatMap((line) => {
    const product = getProduct(line.productId);
    return product ? [{ ...line, product }] : [];
  });
  const subtotal = lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0);

  if (lines.length === 0) return <EmptyState title="Your cart is empty" copy="Explore the collection and add a fragrance to begin." />;

  return (
    <div className="flex min-h-0 flex-col">
      <div className="space-y-3">
        {lines.map(({ product, quantity }) => {
          const atStockLimit = quantity >= product.stock;
          const outOfStock = product.stock <= 0;
          return (
            <div key={product.id} className="grid grid-cols-[72px_1fr_auto] gap-4 border-b border-border py-4">
              <img src={product.image} alt="" width={1024} height={1280} className="aspect-[4/5] w-full object-cover" />
              <div className="min-w-0">
                <Link to="/products/$productId" params={{ productId: product.id }} onClick={() => setCartOpen(false)} className="font-display text-xl leading-none text-foreground hover:text-primary">{product.name}</Link>
                <p className="mt-1 text-xs text-muted-foreground">{formatPrice(product.price)}</p>
                {outOfStock ? (
                  <p className="mt-2 text-xs font-medium text-destructive">Now out of stock — remove to continue</p>
                ) : (
                  <div className="mt-3 flex w-fit items-center border border-border">
                    <Button type="button" variant="ghost" size="icon" className="size-8 rounded-none" onClick={() => setQuantity(product.id, quantity - 1)} aria-label={`Decrease ${product.name} quantity`}><Minus /></Button>
                    <span className="w-8 text-center text-xs">{quantity}</span>
                    <Button type="button" variant="ghost" size="icon" className="size-8 rounded-none" disabled={atStockLimit} onClick={() => setQuantity(product.id, Math.min(quantity + 1, product.stock))} aria-label={`Increase ${product.name} quantity`}><Plus /></Button>
                  </div>
                )}
                {!outOfStock && atStockLimit && <p className="mt-1 text-xs text-amber-600">Max available stock reached</p>}
              </div>
              <Button type="button" variant="ghost" size="icon" className="size-8 text-muted-foreground" onClick={() => removeFromCart(product.id)} aria-label={`Remove ${product.name}`}><Trash2 /></Button>
            </div>
          );
        })}
      </div>
      <div className="mt-6 border-t border-border pt-5">
        <div className="flex items-center justify-between"><span className="text-sm text-muted-foreground">Subtotal</span><strong className="text-lg">{formatPrice(subtotal)}</strong></div>
        <p className="mt-2 text-xs text-muted-foreground">Checkout and payments will be added in a later phase.</p>
        {compact && <Button asChild className="mt-5 w-full rounded-none" onClick={() => setCartOpen(false)}><Link to="/cart">View full cart</Link></Button>}
      </div>
    </div>
  );
}