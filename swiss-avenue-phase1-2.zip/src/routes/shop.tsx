import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Search, X } from "lucide-react";
import { z } from "zod";

import { SiteHeader } from "@/components/storefront/site-header";
import { SiteFooter } from "@/components/storefront/site-footer";
import { ProductCard } from "@/components/storefront/product-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PRODUCT_TYPES, products } from "@/lib/products";

const shopSearchSchema = z.object({
  q: z.string().optional(),
  type: z.string().optional(),
  sort: z.enum(["newest", "price-asc", "price-desc"]).optional(),
  focus: z.string().optional(),
});

export const Route = createFileRoute("/shop")({
  validateSearch: shopSearchSchema,
  head: () => ({
    meta: [
      { title: "Shop — Swiss Avenue" },
      {
        name: "description",
        content: "Browse the full Swiss Avenue fragrance collection. Search by name or notes, filter by type, and sort by price.",
      },
    ],
  }),
  component: ShopPage,
});

const SORTS = [
  { value: "newest", label: "Newest" },
  { value: "price-asc", label: "Price: Low to high" },
  { value: "price-desc", label: "Price: High to low" },
] as const;

function ShopPage() {
  const search = Route.useSearch();
  const inputRef = useRef<HTMLInputElement>(null);

  const [q, setQ] = useState(search.q ?? "");
  const [type, setType] = useState<string>(search.type ?? "all");
  const [sort, setSort] = useState<string>(search.sort ?? "newest");

  useEffect(() => {
    if (search.focus === "search") inputRef.current?.focus();
  }, [search.focus]);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    const list = products.filter((product) => {
      const matchesQuery =
        !query ||
        product.name.toLowerCase().includes(query) ||
        product.type.toLowerCase().includes(query) ||
        product.notes.toLowerCase().includes(query);
      const matchesType = type === "all" || product.type === type;
      return matchesQuery && matchesType;
    });
    return [...list].sort((a, b) => {
      if (sort === "price-asc") return a.price - b.price;
      if (sort === "price-desc") return b.price - a.price;
      return b.createdAt - a.createdAt;
    });
  }, [q, type, sort]);

  const hasActiveFilters = q.trim() !== "" || type !== "all";

  function resetFilters() {
    setQ("");
    setType("all");
    setSort("newest");
  }

  return (
    <>
      <SiteHeader />
      <main className="bg-background">
        <section className="border-b border-border bg-secondary/40 px-5 py-12 sm:px-8 lg:px-10">
          <div className="mx-auto max-w-[1480px]">
            <p className="eyebrow text-muted-foreground">Full collection</p>
            <h1 className="mt-3 font-display text-5xl text-foreground sm:text-6xl">Shop fragrances</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-muted-foreground">
              {products.length} fragrances across Eau de Parfum, Oud, Attar and more — search, filter and sort to find yours.
            </p>
          </div>
        </section>

        <section className="px-5 py-8 sm:px-8 lg:px-10">
          <div className="mx-auto max-w-[1480px]">
            <div className="flex flex-col gap-3 border-b border-border pb-6 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  ref={inputRef}
                  value={q}
                  onChange={(event) => setQ(event.target.value)}
                  placeholder="Search by name, notes, or type"
                  className="rounded-none pl-9"
                  aria-label="Search products"
                />
              </div>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="w-full rounded-none sm:w-48" aria-label="Filter by type">
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All types</SelectItem>
                  {PRODUCT_TYPES.map((productType) => (
                    <SelectItem key={productType} value={productType}>
                      {productType}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={sort} onValueChange={setSort}>
                <SelectTrigger className="w-full rounded-none sm:w-56" aria-label="Sort products">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SORTS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {hasActiveFilters && (
                <Button type="button" variant="ghost" onClick={resetFilters} className="gap-1 text-muted-foreground">
                  <X className="size-4" /> Reset
                </Button>
              )}
            </div>

            <p className="mt-4 text-xs text-muted-foreground">
              {filtered.length} {filtered.length === 1 ? "result" : "results"}
            </p>

            {filtered.length === 0 ? (
              <div className="mt-10 grid place-items-center border border-border bg-card px-6 py-16 text-center">
                <div>
                  <Search className="mx-auto size-8 text-primary" />
                  <h2 className="mt-5 font-display text-4xl text-foreground">No fragrances found</h2>
                  <p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-muted-foreground">
                    Try a different search term, or reset filters to see the full collection.
                  </p>
                  <Button type="button" onClick={resetFilters} className="mt-7 rounded-none">
                    Reset filters
                  </Button>
                </div>
              </div>
            ) : (
              <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {filtered.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
