import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type CSSProperties, type FormEvent, type ReactNode } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  Check,
  Globe2,
  Mail,
  Menu,
  MessageCircle,
  Phone,
  ShoppingBag,
  Store,
  X,
} from "lucide-react";

import heroImage from "@/assets/fragrance-hero.jpg";
import collectionImage from "@/assets/fragrance-collection.jpg";
import sourcingImage from "@/assets/fragrance-sourcing.jpg";
import swissAvenueLogo from "@/assets/swiss-avenue-logo.png.asset.json";
import { Button } from "@/components/ui/button";

const BRAND = "Swiss Avenue";
const OWNER = "Maaz Kazi";
const PHONE = "9028905454";
const EMAIL = "Maazkazi8000@gmail.com";
const WHATSAPP_MESSAGE = "Hi Swiss Avenue, I'd like to enquire about your fragrances.";

const INTRO_PARTICLES = [
  { left: 18, top: 28, size: 3, duration: 7.5, delay: 0, opacity: 0.55 },
  { left: 82, top: 22, size: 2, duration: 6.5, delay: 0.6, opacity: 0.45 },
  { left: 28, top: 68, size: 4, duration: 8.5, delay: 1.1, opacity: 0.5 },
  { left: 72, top: 72, size: 2, duration: 7, delay: 0.3, opacity: 0.4 },
  { left: 12, top: 50, size: 2, duration: 9, delay: 1.8, opacity: 0.35 },
  { left: 88, top: 48, size: 3, duration: 7.8, delay: 0.9, opacity: 0.5 },
  { left: 50, top: 15, size: 2, duration: 6.8, delay: 1.4, opacity: 0.4 },
  { left: 40, top: 84, size: 3, duration: 8, delay: 0.4, opacity: 0.45 },
  { left: 62, top: 34, size: 2, duration: 7.2, delay: 2, opacity: 0.35 },
  { left: 8, top: 80, size: 2, duration: 9.5, delay: 0.8, opacity: 0.4 },
  { left: 94, top: 78, size: 3, duration: 6.9, delay: 1.6, opacity: 0.45 },
  { left: 56, top: 58, size: 2, duration: 8.3, delay: 0.2, opacity: 0.35 },
];

const products = [
  { name: "Anatolian Ember", origin: "Istanbul", notes: "Saffron · Rose · Smoked Oud", size: "80 ml", price: "$128" },
  { name: "Verdant No. 07", origin: "Grasse", notes: "Bergamot · Fig Leaf · Vetiver", size: "75 ml", price: "$116" },
  { name: "Bosporus Veil", origin: "Istanbul", notes: "Iris · White Tea · Cedar", size: "80 ml", price: "$124" },
  { name: "Nocturne Resin", origin: "Dubai", notes: "Incense · Amber · Black Musk", size: "100 ml", price: "$142" },
];

const quotes = [
  "Scent is the quietest form of presence.",
  "Memory begins where language ends.",
  "Luxury is what remains after you leave.",
  "A fine fragrance never asks to be noticed.",
  "Every note carries a place within it.",
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${BRAND} — Imported Luxury Fragrances` },
      { name: "description", content: "A considered collection of authentic fragrances sourced from Turkey and renowned perfume regions worldwide, available retail and wholesale." },
      { property: "og:title", content: `${BRAND} — Imported Luxury Fragrances` },
      { property: "og:description", content: "Turkish and international fragrances, selected with provenance and available for retail and wholesale." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FragranceHouse,
});

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <img
      src={swissAvenueLogo.url}
      alt={BRAND}
      width={1547}
      height={753}
      className={compact ? "h-auto w-48 sm:w-60" : "h-auto w-32 sm:w-40"}
    />
  );
}

function NavItem({ href, className, onClick, children }: { href: string; className?: string; onClick?: () => void; children: ReactNode }) {
  if (href.startsWith("/")) {
    return (
      <Link to={href} className={className} onClick={onClick}>
        {children}
      </Link>
    );
  }
  return (
    <a href={href} className={className} onClick={onClick}>
      {children}
    </a>
  );
}

function Intro({ onDone }: { onDone: () => void }) {
  const [exiting, setExiting] = useState(false);

  // Hold on the entrance sequence, then hand off to the iris-wipe exit.
  useEffect(() => {
    const enter = window.setTimeout(() => setExiting(true), 4700);
    return () => window.clearTimeout(enter);
  }, []);

  // Once the exit is triggered (by timer or Skip), let the wipe animation
  // finish playing before actually unmounting.
  useEffect(() => {
    if (!exiting) return;
    const leave = window.setTimeout(onDone, 950);
    return () => window.clearTimeout(leave);
  }, [exiting, onDone]);

  return (
    <div
      className={`intro fixed inset-0 z-[100] grid place-items-center overflow-hidden bg-ink text-ivory ${exiting ? "intro-exiting" : ""}`}
      role="dialog"
      aria-label="Brand introduction"
    >
      <div className="intro-glow" aria-hidden="true" />
      <div className="intro-sweep" aria-hidden="true" />
      <div className="intro-particles" aria-hidden="true">
        {INTRO_PARTICLES.map((particle, i) => (
          <span
            key={i}
            className="intro-particle"
            style={
              {
                left: `${particle.left}%`,
                top: `${particle.top}%`,
                width: particle.size,
                height: particle.size,
                "--dur": `${particle.duration}s`,
                "--delay": `${particle.delay}s`,
                "--op": particle.opacity,
              } as CSSProperties
            }
          />
        ))}
      </div>
      <div className="intro-mark flex flex-col items-center px-6 text-center">
        <Logo />
        <span className="intro-line mt-6 h-px w-52 bg-brass" />
        <p className="intro-tagline mt-5 font-display text-xl italic text-ivory/70">Fragrance, found with intention.</p>
      </div>
      <div className="intro-progress" aria-hidden="true">
        <span />
      </div>
      <button
        onClick={() => setExiting(true)}
        className="intro-skip absolute bottom-8 right-7 z-10 text-xs text-ivory/60 transition-colors hover:text-brass focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-brass"
      >
        Skip intro
      </button>
    </div>
  );
}

function FragranceHouse() {
  const [showIntro, setShowIntro] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const seen = sessionStorage.getItem("fragrance-intro-seen");
    if (!reduced && !seen) setShowIntro(true);
  }, []);

  function finishIntro() {
    sessionStorage.setItem("fragrance-intro-seen", "true");
    setShowIntro(false);
  }

  function submitEnquiry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const message = `${WHATSAPP_MESSAGE}\n\nName: ${data.get("name")}\nPhone: ${data.get("phone")}\nEnquiry: ${data.get("customerType")}\n\n${data.get("message")}`;
    window.open(`https://wa.me/91${PHONE}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
  }

  const nav = [
    ["Home", "#home"], ["Shop", "/shop"], ["Collection", "#collection"], ["Imported Fragrances", "#origins"],
    ["Wholesale", "#trade"], ["About", "#story"], ["Contact", "#contact"],
  ];

  return (
    <>
      {showIntro && <Intro onDone={finishIntro} />}
      <header className="fixed inset-x-0 top-0 z-50 border-b border-ivory/10 bg-ink/85 text-ivory backdrop-blur-xl">
        <div className="mx-auto grid h-20 max-w-[1480px] grid-cols-[minmax(0,1fr)_auto] items-center px-5 lg:grid-cols-[auto_1fr_auto] lg:px-10">
          <a href="#home" className="w-fit focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-brass"><Logo /></a>
          <nav className="mx-auto hidden items-center gap-7 lg:flex" aria-label="Main navigation">
            {nav.map(([label, href]) => <NavItem key={href} href={href} className="nav-link text-[0.68rem] tracking-[0.14em] text-ivory/65 transition-colors hover:text-ivory">{label}</NavItem>)}
          </nav>
          <Button asChild className="hidden rounded-none border border-brass bg-transparent px-5 text-[0.68rem] tracking-[0.14em] text-brass shadow-none hover:bg-brass hover:text-ink lg:inline-flex">
            <a href="#contact">Enquire now <ArrowDownRight /></a>
          </Button>
          <button className="grid h-10 w-10 place-items-center text-ivory lg:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label="Toggle menu">
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>
        {menuOpen && <nav className="border-t border-ivory/10 bg-ink px-5 py-6 lg:hidden" aria-label="Mobile navigation">{nav.map(([label, href]) => <NavItem key={href} href={href} onClick={() => setMenuOpen(false)} className="block border-b border-ivory/10 py-3 font-display text-xl text-ivory">{label}</NavItem>)}</nav>}
      </header>

      <main>
        <section id="home" className="relative min-h-[94svh] overflow-hidden bg-ink pt-20 text-ivory">
          <img src={heroImage} alt="Amber fragrance bottle on black stone" width={1536} height={1920} className="absolute inset-0 h-full w-full object-cover object-[68%_center] opacity-75" />
          <div className="hero-shade absolute inset-0" />
          <div className="relative mx-auto flex min-h-[calc(94svh-5rem)] max-w-[1480px] items-end px-5 pb-16 sm:px-8 lg:px-10 lg:pb-24">
            <div className="max-w-4xl animate-rise">
              <p className="mb-6 text-xs tracking-[0.18em] text-brass">ISTANBUL · PARIS · DUBAI · BEYOND</p>
              <h1 className="font-display text-[clamp(3.25rem,8vw,8.8rem)] leading-[0.88]">The world’s finest scents, <em className="font-normal text-brass">considered.</em></h1>
              <div className="mt-8 grid max-w-3xl gap-7 border-t border-ivory/20 pt-7 sm:grid-cols-[1fr_auto] sm:items-end">
                <p className="max-w-xl text-base leading-7 text-ivory/68 sm:text-lg">A discerning edit of Turkish perfumery and international fragrance houses, imported with provenance for private clients and trade partners.</p>
                <div className="flex flex-wrap gap-3">
                  <Button asChild className="rounded-none bg-brass px-6 text-ink hover:bg-ivory"><a href="#collection">Explore collection <ArrowRight /></a></Button>
                  <Button asChild variant="outline" className="rounded-none border-ivory/30 bg-transparent px-6 text-ivory shadow-none hover:bg-ivory hover:text-ink"><a href="#trade">Wholesale enquiry</a></Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="marquee overflow-hidden border-y border-brass/30 bg-bottle py-4 text-ivory" aria-label="Fragrance reflections">
          <div className="marquee-track flex w-max gap-12 whitespace-nowrap">
            {[...quotes, ...quotes].map((quote, i) => <span key={i} className="flex items-center gap-12 font-display text-lg italic"><span>{quote}</span><span className="text-brass">✦</span></span>)}
          </div>
        </div>

        <section id="collection" className="bg-ivory text-ink section-pad">
          <div className="mx-auto max-w-[1480px] px-5 sm:px-8 lg:px-10">
            <div className="mb-12 grid gap-6 border-b border-ink/20 pb-8 md:grid-cols-[1fr_1fr] md:items-end">
              <div><p className="eyebrow">The private edit · 01</p><h2 className="section-title mt-4">Featured collection</h2></div>
              <p className="max-w-lg text-sm leading-7 text-ink/65 md:justify-self-end">Four distinctive compositions chosen for clarity, character, and exceptional wear. Every bottle is sourced through established partners.</p>
            </div>
            <div className="grid gap-4 bg-transparent sm:grid-cols-2 lg:grid-cols-4 lg:gap-5">
              {products.map((product, i) => (
                <article key={product.name} className="perfume-card group bg-ivory p-4 sm:p-5">
                  <div className="perfume-card-image relative aspect-[4/5] overflow-hidden bg-stone">
                    <img src={collectionImage} alt={`${product.name} perfume bottle`} width={1920} height={1280} loading="lazy" className={`h-full w-[210%] max-w-none object-cover transition-transform duration-700 group-hover:scale-[1.03] ${i === 0 ? "object-[8%_center]" : i === 1 ? "-translate-x-[23%] object-center" : i === 2 ? "-translate-x-[46%] object-center" : "-translate-x-[52%] object-center"}`} />
                    <span className="absolute left-3 top-3 bg-ink px-2 py-1 text-[0.6rem] tracking-[0.14em] text-ivory">{product.origin}</span>
                  </div>
                   <div className="mt-5 flex items-start justify-between gap-3"><h3 className="font-display text-2xl leading-none">{product.name}</h3><span className="text-sm font-medium text-ink/60">{product.price}</span></div>
                  <p className="mt-2 text-xs text-ink/55">{product.notes}</p>
                  <div className="mt-5 flex items-center justify-between border-t border-ink/15 pt-4"><span className="text-xs text-ink/45">Eau de Parfum · {product.size}</span><a href="#contact" className="text-ink transition-colors hover:text-brass" aria-label={`Enquire about ${product.name}`}><ArrowRight className="size-4" /></a></div>
                </article>
              ))}
            </div>
            <p className="mt-5 text-xs text-ink/45">Sample collection and pricing — final catalogue details to be confirmed before publishing.</p>
          </div>
        </section>

        <section id="origins" className="bg-stone text-ink section-pad">
          <div className="mx-auto grid max-w-[1480px] gap-12 px-5 sm:px-8 lg:grid-cols-[1.1fr_.9fr] lg:px-10">
            <div className="relative min-h-[420px] overflow-hidden lg:min-h-[680px]"><img src={sourcingImage} alt="Perfume with rose, saffron, citrus peel and woods" width={1920} height={1280} loading="lazy" className="absolute inset-0 h-full w-full object-cover" /></div>
            <div className="flex flex-col justify-between lg:py-8">
              <div><p className="eyebrow">Provenance · 02</p><h2 className="section-title mt-4">Sourced beyond borders.<br /><em>Selected without compromise.</em></h2><p className="mt-8 max-w-xl text-base leading-8 text-ink/65">Our collection begins in Turkey—where modern composition meets a centuries-old culture of aromatic material—and extends through trusted perfume centres worldwide. We select for originality, verified supply, and the integrity of every bottle.</p></div>
              <div className="mt-12 border-t border-ink/20">
                {[['TR','Turkey','Contemporary ateliers & attars'],['FR','France','Fine fragrance tradition'],['AE','UAE','Oud & modern oriental accords'],['IT','Italy','Citrus, leather & aromatic craft']].map(([code,country,detail]) => <div key={code} className="grid grid-cols-[42px_1fr] gap-4 border-b border-ink/20 py-4"><span className="font-display text-brass">{code}</span><div className="flex flex-wrap justify-between gap-2"><strong className="font-normal">{country}</strong><span className="text-sm text-ink/50">{detail}</span></div></div>)}
              </div>
            </div>
          </div>
        </section>

        <section id="trade" className="bg-ivory text-ink section-pad">
          <div className="mx-auto max-w-[1480px] px-5 sm:px-8 lg:px-10">
            <p className="eyebrow">Two ways to discover · 03</p>
             <div className="mt-8 grid gap-5 md:grid-cols-2">
               <div className="trade-panel group p-8 sm:p-10 lg:p-12"><ShoppingBag className="mb-8 size-7 text-brass" /><h2 className="font-display text-4xl leading-none sm:text-5xl">For your collection</h2><p className="mt-5 max-w-lg leading-7 text-ink/60">Discover singular scents for daily ritual, gifting, and the moments worth remembering. Personal guidance is available for every selection.</p><Button asChild className="mt-9 rounded-none bg-ink px-6 text-ivory hover:bg-bottle"><Link to="/shop">Shop the edit <ArrowRight /></Link></Button></div>
               <div className="trade-panel group p-8 sm:p-10 lg:p-12"><Store className="mb-8 size-7 text-brass" /><h2 className="font-display text-4xl leading-none sm:text-5xl">For the trade</h2><p className="mt-5 max-w-lg leading-7 text-ink/60">A reliable import partner for boutiques, gifting businesses, and distributors. Ask about opening quantities, mixed cases, and recurring supply.</p><Button asChild className="mt-9 rounded-none bg-bottle px-6 text-ivory hover:bg-ink"><a href="#contact">Get wholesale pricing <ArrowRight /></a></Button></div>
            </div>
          </div>
        </section>

        <section id="story" className="relative overflow-hidden bg-ink text-ivory section-pad">
          <div className="story-glow absolute inset-y-0 right-0 w-1/2" />
          <div className="relative mx-auto grid max-w-[1480px] gap-12 px-5 sm:px-8 lg:grid-cols-[.7fr_1.3fr] lg:px-10">
            <div><p className="eyebrow text-brass">The house · 04</p><Globe2 className="mt-10 size-12 stroke-[.75] text-brass/60" /></div>
            <div><h2 className="section-title max-w-4xl">We look for fragrance with a point of view—not simply a familiar name.</h2><div className="mt-12 grid gap-10 border-t border-ivory/20 pt-10 md:grid-cols-2"><p className="leading-8 text-ivory/62">Our work is equal parts discernment and discipline. We build direct, considered relationships with suppliers, review provenance, and choose compositions that earn their place on the shelf.</p><blockquote className="font-display text-3xl italic leading-snug text-brass">“A collection should feel discovered, not assembled.”</blockquote></div></div>
          </div>
        </section>

        <section className="bg-ivory text-ink section-pad" aria-labelledby="trust-title">
          <div className="mx-auto max-w-[1480px] px-5 sm:px-8 lg:px-10">
            <div className="grid gap-6 md:grid-cols-[.65fr_1.35fr]"><div><p className="eyebrow">Client notes · 05</p><h2 id="trust-title" className="section-title mt-4">Quietly trusted.</h2></div><div className="border-t border-ink/20">
              {[['The selection feels genuinely edited. Every bottle has a reason to be there, and the guidance was exact.','— Private client'],['Our mixed opening order arrived carefully packed and ready for the floor. The follow-through was exceptional.','— Independent retailer'],['They understood the brief immediately: distinctive, gift-worthy, and not what every other shop carries.','— Corporate gifting partner']].map(([text, by], i) => <blockquote key={by} className="grid gap-5 border-b border-ink/20 py-8 sm:grid-cols-[40px_1fr_auto]"><span className="font-display text-3xl text-brass">0{i+1}</span><p className="font-display text-2xl leading-snug">“{text}”</p><cite className="self-end text-xs not-italic text-ink/50">{by}</cite></blockquote>)}
            </div></div>
          </div>
        </section>

        <section id="contact" className="bg-bottle text-ivory section-pad">
          <div className="mx-auto grid max-w-[1480px] gap-14 px-5 sm:px-8 lg:grid-cols-[.8fr_1.2fr] lg:px-10">
             <div><p className="eyebrow text-brass">Begin a conversation · 06</p><h2 className="section-title mt-4">Tell us what you’re looking for.</h2><p className="mt-7 max-w-md leading-7 text-ivory/60">For a personal recommendation, a gift, or a wholesale range, share a few details and we’ll continue the conversation on WhatsApp.</p><div className="mt-10 space-y-4 border-t border-ivory/20 pt-7"><a href={`tel:+91${PHONE}`} className="flex items-center gap-3 text-sm hover:text-brass"><Phone className="size-4" />{PHONE}</a><a href={`mailto:${EMAIL}`} className="flex items-center gap-3 text-sm hover:text-brass"><Mail className="size-4" />{EMAIL}</a><p className="text-sm text-ivory/60">Owned by {OWNER}</p></div></div>
            <form onSubmit={submitEnquiry} className="grid gap-7" aria-label="Enquiry form">
              <div className="grid gap-7 sm:grid-cols-2"><label className="form-field"><span>Your name</span><input name="name" required autoComplete="name" placeholder="Full name" /></label><label className="form-field"><span>Phone</span><input name="phone" required autoComplete="tel" placeholder="With country code" /></label></div>
              <fieldset><legend className="mb-3 text-xs text-ivory/60">I’m enquiring for</legend><div className="flex gap-5"><label className="flex items-center gap-2 text-sm"><input type="radio" name="customerType" value="Retail" defaultChecked className="accent-brass" /> Retail</label><label className="flex items-center gap-2 text-sm"><input type="radio" name="customerType" value="Wholesale" className="accent-brass" /> Wholesale</label></div></fieldset>
              <label className="form-field"><span>How can we help?</span><textarea name="message" required rows={4} placeholder="Tell us about the fragrance, quantity, or occasion" /></label>
              <Button type="submit" className="h-12 w-fit rounded-none bg-brass px-7 text-ink hover:bg-ivory">Send via WhatsApp <MessageCircle /></Button>
            </form>
          </div>
        </section>
      </main>

      <footer className="border-t border-ivory/10 bg-ink px-5 py-12 text-ivory sm:px-8 lg:px-10">
         <div className="mx-auto grid max-w-[1480px] gap-10 md:grid-cols-[1fr_auto_auto] md:items-end"><div><Logo /><p className="mt-5 max-w-sm text-sm leading-6 text-ivory/45">Imported fragrance for private collections and discerning trade partners.</p></div><div className="grid grid-cols-2 gap-x-10 gap-y-2 text-xs text-ivory/55">{nav.slice(1).map(([label,href]) => <a key={href} href={href} className="hover:text-brass">{label}</a>)}</div><div className="text-xs leading-6 text-ivory/45 md:text-right"><p>{PHONE}</p><p>{EMAIL}</p><p>Owned by {OWNER}</p></div></div>
        <div className="mx-auto mt-12 flex max-w-[1480px] flex-wrap justify-between gap-3 border-t border-ivory/10 pt-5 text-[0.65rem] text-ivory/35"><span>© 2026 {BRAND}. All rights reserved.</span><span>Fragrance, found with intention.</span></div>
      </footer>

      <div className="fixed bottom-5 right-5 z-40 flex flex-col gap-2">
         <a href={`https://wa.me/91${PHONE}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp" className="floating-action bg-brass text-ink"><MessageCircle /></a>
         <a href={`tel:+91${PHONE}`} aria-label="Call now" className="floating-action bg-ivory text-ink"><Phone /></a>
      </div>
    </>
  );
}