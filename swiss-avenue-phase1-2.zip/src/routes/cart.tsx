import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

import { SiteHeader } from "@/components/storefront/site-header";
import { SiteFooter } from "@/components/storefront/site-footer";
import { CartContent } from "@/components/storefront/cart-content";
import { Button } from "@/components/ui/button";
import { getProduct } from "@/lib/products";
import { useStorefront } from "@/lib/storefront";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your cart — Swiss Avenue" },
      { name: "description", content: "Review your selected fragrances before checkout." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { cart } = useStorefront();
  const hasUnavailableItem = cart.some((line) => {
    const product = getProduct(line.productId);
    return !product || product.stock <= 0 || line.quantity > product.stock;
  });

  return (
    <>
      <SiteHeader />
      <main className="bg-background">
        <section className="border-b border-border bg-secondary/40 px-5 py-12 sm:px-8 lg:px-10">
          <div className="mx-auto max-w-[1480px]">
            <p className="eyebrow text-muted-foreground">Your selection</p>
            <h1 className="mt-3 font-display text-5xl text-foreground sm:text-6xl">Cart</h1>
          </div>
        </section>

        <section className="px-5 py-10 sm:px-8 lg:px-10">
          <div className="mx-auto max-w-[1480px]">
            <div className="mx-auto max-w-2xl">
              <CartContent />

              {cart.length > 0 && (
                <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-between">
                  <Button asChild variant="outline" className="h-11 rounded-none">
                    <Link to="/shop"><ArrowLeft /> Continue shopping</Link>
                  </Button>
                  <Button type="button" disabled={hasUnavailableItem} className="h-11 rounded-none" title="Checkout and payments arrive in a later phase">
                    Proceed to checkout
                  </Button>
                </div>
              )}
              {hasUnavailableItem && (
                <p className="mt-3 text-center text-xs text-destructive sm:text-right">
                  Remove or adjust unavailable items before checkout.
                </p>
              )}
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
