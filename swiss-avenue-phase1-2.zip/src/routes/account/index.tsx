import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { LogOut, Plus, Trash2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";

import { SiteHeader } from "@/components/storefront/site-header";
import { SiteFooter } from "@/components/storefront/site-footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { getSupabaseBrowserClient } from "@/lib/supabase/client";
import type { Database } from "@/lib/supabase/types";

type Address = Database["public"]["Tables"]["addresses"]["Row"];

export const Route = createFileRoute("/account/")({
  head: () => ({ meta: [{ title: "My account — Swiss Avenue" }] }),
  component: AccountPage,
});

function AccountPage() {
  const { user, profile, loading, signOut, configured } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && configured && !user) {
      navigate({ to: "/login", search: { redirect: "/account" } });
    }
  }, [loading, configured, user, navigate]);

  if (!configured) {
    return (
      <>
        <SiteHeader />
        <main className="grid min-h-[50vh] place-items-center bg-background px-6 text-center">
          <p className="max-w-sm text-sm text-muted-foreground">
            Authentication isn't configured yet — set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment.
          </p>
        </main>
        <SiteFooter />
      </>
    );
  }

  if (loading || !user) {
    return (
      <>
        <SiteHeader />
        <main className="grid min-h-[50vh] place-items-center bg-background">
          <p className="text-sm text-muted-foreground">Loading your account…</p>
        </main>
        <SiteFooter />
      </>
    );
  }

  return (
    <>
      <SiteHeader />
      <main className="bg-background">
        <section className="border-b border-border bg-secondary/40 px-5 py-12 sm:px-8 lg:px-10">
          <div className="mx-auto max-w-[1080px]">
            <p className="eyebrow text-muted-foreground">Welcome back</p>
            <h1 className="mt-3 font-display text-5xl text-foreground sm:text-6xl">{profile?.full_name || "Your account"}</h1>
          </div>
        </section>

        <section className="px-5 py-10 sm:px-8 lg:px-10">
          <div className="mx-auto grid max-w-[1080px] gap-10 lg:grid-cols-[1fr_1.4fr]">
            <div className="space-y-8">
              <div className="border border-border bg-card p-6">
                <h2 className="font-display text-2xl text-foreground">Profile</h2>
                <dl className="mt-4 space-y-2 text-sm">
                  <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Name</dt><dd className="text-right text-foreground">{profile?.full_name || "—"}</dd></div>
                  <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Email</dt><dd className="text-right text-foreground">{user.email}</dd></div>
                  <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Phone</dt><dd className="text-right text-foreground">{profile?.phone || "—"}</dd></div>
                </dl>
                <Button type="button" variant="outline" onClick={() => signOut()} className="mt-6 w-full gap-2 rounded-none">
                  <LogOut className="size-4" /> Log out
                </Button>
              </div>

              <div className="border border-border bg-card p-6">
                <h2 className="font-display text-2xl text-foreground">Orders</h2>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">
                  Order history will appear here once checkout goes live in the next phase. For now, browse the{" "}
                  <Link to="/shop" className="text-primary hover:underline">shop</Link>.
                </p>
              </div>
            </div>

            <AddressBook userId={user.id} />
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}

function AddressBook({ userId }: { userId: string }) {
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    line1: "",
    line2: "",
    city: "",
    state: "",
    postalCode: "",
  });

  useEffect(() => {
    let cancelled = false;
    getSupabaseBrowserClient()
      .from("addresses")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        if (!cancelled) {
          setAddresses(data ?? []);
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [userId]);

  async function handleAdd(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setSaving(true);
    const { data, error: insertError } = await getSupabaseBrowserClient()
      .from("addresses")
      .insert({
        user_id: userId,
        full_name: form.fullName,
        phone: form.phone,
        line1: form.line1,
        line2: form.line2 || null,
        city: form.city,
        state: form.state,
        postal_code: form.postalCode,
        is_default: addresses.length === 0,
      })
      .select("*")
      .single();
    setSaving(false);

    if (insertError) {
      setError(insertError.message);
      return;
    }
    if (data) setAddresses((current) => [data, ...current]);
    setForm({ fullName: "", phone: "", line1: "", line2: "", city: "", state: "", postalCode: "" });
    setAdding(false);
  }

  async function handleDelete(id: string) {
    setAddresses((current) => current.filter((address) => address.id !== id));
    await getSupabaseBrowserClient().from("addresses").delete().eq("id", id);
  }

  return (
    <div className="border border-border bg-card p-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-2xl text-foreground">Saved addresses</h2>
        {!adding && (
          <Button type="button" variant="outline" size="sm" onClick={() => setAdding(true)} className="gap-1 rounded-none">
            <Plus className="size-4" /> Add address
          </Button>
        )}
      </div>

      {loading ? (
        <p className="mt-4 text-sm text-muted-foreground">Loading addresses…</p>
      ) : addresses.length === 0 && !adding ? (
        <p className="mt-4 text-sm text-muted-foreground">No saved addresses yet.</p>
      ) : (
        <div className="mt-4 space-y-3">
          {addresses.map((address) => (
            <div key={address.id} className="flex items-start justify-between gap-4 border border-border p-4 text-sm">
              <div>
                <p className="font-medium text-foreground">{address.full_name} {address.is_default && <span className="ml-2 text-xs font-normal text-primary">Default</span>}</p>
                <p className="mt-1 text-muted-foreground">{address.line1}{address.line2 ? `, ${address.line2}` : ""}</p>
                <p className="text-muted-foreground">{address.city}, {address.state} {address.postal_code}</p>
                <p className="text-muted-foreground">{address.phone}</p>
              </div>
              <Button type="button" variant="ghost" size="icon" className="shrink-0 text-muted-foreground" onClick={() => handleDelete(address.id)} aria-label="Delete address">
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      {adding && (
        <form onSubmit={handleAdd} className="mt-5 space-y-4 border-t border-border pt-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="addr-name">Full name</Label>
              <Input id="addr-name" required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} className="rounded-none" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="addr-phone">Phone</Label>
              <Input id="addr-phone" required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="rounded-none" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="addr-line1">Address line 1</Label>
            <Input id="addr-line1" required value={form.line1} onChange={(e) => setForm({ ...form, line1: e.target.value })} className="rounded-none" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="addr-line2">Address line 2 (optional)</Label>
            <Input id="addr-line2" value={form.line2} onChange={(e) => setForm({ ...form, line2: e.target.value })} className="rounded-none" />
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-1.5">
              <Label htmlFor="addr-city">City</Label>
              <Input id="addr-city" required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="rounded-none" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="addr-state">State</Label>
              <Input id="addr-state" required value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} className="rounded-none" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="addr-postal">Postal code</Label>
              <Input id="addr-postal" required value={form.postalCode} onChange={(e) => setForm({ ...form, postalCode: e.target.value })} className="rounded-none" />
            </div>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="flex gap-3">
            <Button type="submit" disabled={saving} className="rounded-none">{saving ? "Saving…" : "Save address"}</Button>
            <Button type="button" variant="ghost" onClick={() => setAdding(false)} className="rounded-none">Cancel</Button>
          </div>
        </form>
      )}
    </div>
  );
}
