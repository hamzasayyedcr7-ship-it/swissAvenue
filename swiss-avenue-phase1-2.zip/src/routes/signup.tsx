import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";

import { SiteHeader } from "@/components/storefront/site-header";
import { SiteFooter } from "@/components/storefront/site-footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/signup")({
  head: () => ({ meta: [{ title: "Create account — Swiss Avenue" }] }),
  component: SignupPage,
});

function SignupPage() {
  const { signUp, configured } = useAuth();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [needsConfirmation, setNeedsConfirmation] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);

    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords don't match.");
      return;
    }

    setSubmitting(true);
    const { error: signUpError, needsEmailConfirmation } = await signUp({ email, password, fullName, phone });
    setSubmitting(false);

    if (signUpError) {
      setError(signUpError);
      return;
    }
    if (needsEmailConfirmation) {
      setNeedsConfirmation(true);
      return;
    }
    navigate({ to: "/account" });
  }

  if (needsConfirmation) {
    return (
      <>
        <SiteHeader />
        <main className="grid min-h-[70vh] place-items-center bg-background px-5 py-16 text-center">
          <div className="max-w-sm">
            <h1 className="font-display text-4xl text-foreground">Check your email</h1>
            <p className="mt-3 text-sm leading-6 text-muted-foreground">
              We've sent a confirmation link to <strong className="text-foreground">{email}</strong>. Follow it to activate your account, then log in.
            </p>
            <Button asChild className="mt-7 rounded-none">
              <Link to="/login">Go to login</Link>
            </Button>
          </div>
        </main>
        <SiteFooter />
      </>
    );
  }

  return (
    <>
      <SiteHeader />
      <main className="grid min-h-[70vh] place-items-center bg-background px-5 py-16">
        <div className="w-full max-w-sm">
          <h1 className="font-display text-4xl text-foreground">Create an account</h1>
          <p className="mt-2 text-sm text-muted-foreground">Save addresses, track orders, and build a wishlist.</p>

          {!configured && (
            <p className="mt-5 border border-destructive/40 bg-destructive/5 p-3 text-xs text-destructive">
              Authentication isn't configured yet — set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment.
            </p>
          )}

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            <div className="space-y-1.5">
              <Label htmlFor="fullName">Full name</Label>
              <Input id="fullName" required autoComplete="name" value={fullName} onChange={(e) => setFullName(e.target.value)} className="rounded-none" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" type="tel" required autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="rounded-none" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-none" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" required autoComplete="new-password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} className="rounded-none" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="confirmPassword">Confirm password</Label>
              <Input id="confirmPassword" type="password" required autoComplete="new-password" minLength={8} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="rounded-none" />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" disabled={submitting || !configured} className="h-11 w-full rounded-none">
              {submitting ? "Creating account…" : "Create account"}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Already have an account? <Link to="/login" className="text-primary hover:underline">Log in</Link>
          </p>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
