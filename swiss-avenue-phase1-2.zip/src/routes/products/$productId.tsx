import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronRight, Heart, ShoppingBag, Star } from "lucide-react";

import { SiteHeader } from "@/components/storefront/site-header";
import { SiteFooter } from "@/components/storefront/site-footer";
import { ProductCard } from "@/components/storefront/product-card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { formatPrice, getProduct, products } from "@/lib/products";
import { useStorefront } from "@/lib/storefront";

export const Route = createFileRoute("/products/$productId")({
  loader: ({ params }) => {
    const product = getProduct(params.productId);
    if (!product) throw notFound();
    return product;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.name} — Swiss Avenue` },
          { name: "description", content: loaderData.description },
        ]
      : [],
  }),
  notFoundComponent: ProductNotFound,
  component: ProductDetailPage,
});

function ProductNotFound() {
  return (
    <>
      <SiteHeader />
      <main className="grid min-h-[50vh] place-items-center bg-background px-6 text-center">
        <div>
          <h1 className="font-display text-4xl text-foreground">Fragrance not found</h1>
          <p className="mt-3 text-sm text-muted-foreground">It may have been removed from the collection.</p>
          <Button asChild className="mt-6 rounded-none">
            <Link to="/shop">Back to shop</Link>
          </Button>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}

function ProductDetailPage() {
  const product = Route.useLoaderData();
  const { wishlist, toggleWishlist, addToCart, setCartOpen } = useStorefront();
  const [quantity, setQuantity] = useState(1);

  const saved = wishlist.includes(product.id);
  const outOfStock = product.stock <= 0;

  const related = useMemo(
    () =>
      products
        .filter((candidate) => candidate.id !== product.id && candidate.type === product.type)
        .slice(0, 4),
    [product.id, product.type],
  );

  function clampQuantity(next: number) {
    setQuantity(Math.max(1, Math.min(next, Math.max(product.stock, 1))));
  }

  return (
    <>
      <SiteHeader />
      <main className="bg-background">
        <nav className="mx-auto flex max-w-[1480px] items-center gap-1.5 px-5 pt-6 text-xs text-muted-foreground sm:px-8 lg:px-10" aria-label="Breadcrumb">
          <Link to="/shop" className="hover:text-primary">Shop</Link>
          <ChevronRight className="size-3" />
          <span className="text-foreground">{product.name}</span>
        </nav>

        <section className="mx-auto grid max-w-[1480px] gap-10 px-5 py-8 sm:px-8 lg:grid-cols-2 lg:gap-16 lg:px-10 lg:py-12">
          <div className="relative overflow-hidden bg-secondary">
            <img
              src={product.image}
              alt={`${product.name} perfume bottle`}
              width={1024}
              height={1280}
              className={cn("aspect-[4/5] w-full object-cover", outOfStock && "opacity-60 grayscale-[0.3]")}
            />
            {product.discountPercent > 0 && (
              <span className="absolute left-4 top-4 bg-primary px-2.5 py-1 text-xs font-semibold tracking-[0.08em] text-primary-foreground">
                -{product.discountPercent}%
              </span>
            )}
          </div>

          <div className="flex flex-col">
            <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">{product.type} · {product.size}</p>
            <h1 className="mt-3 font-display text-4xl leading-none text-foreground sm:text-5xl">{product.name}</h1>

            <div className="mt-3 flex items-center gap-1.5 text-sm text-muted-foreground">
              <Star className="size-4 fill-primary text-primary" />
              <span className="font-medium text-foreground">{product.rating}</span>
              <span>({product.reviewCount} reviews)</span>
            </div>

            <div className="mt-5 flex items-baseline gap-3">
              <p className="text-2xl font-semibold text-foreground">{formatPrice(product.price)}</p>
              {product.discountPercent > 0 && <p className="text-base text-muted-foreground line-through">{formatPrice(product.mrp)}</p>}
            </div>

            <p className="mt-2 text-sm">
              {outOfStock ? (
                <span className="font-medium text-destructive">Out of stock</span>
              ) : product.stock <= 5 ? (
                <span className="font-medium text-amber-600">Only {product.stock} left in stock</span>
              ) : (
                <span className="text-muted-foreground">In stock</span>
              )}
            </p>

            <p className="mt-6 max-w-xl text-sm leading-7 text-muted-foreground">{product.description}</p>

            <div className="mt-6 border-t border-border pt-6">
              <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Fragrance notes</p>
              <p className="mt-2 text-sm text-foreground">{product.notes}</p>
            </div>

            {!outOfStock && (
              <div className="mt-6 flex items-center gap-4">
                <span className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Quantity</span>
                <div className="flex w-fit items-center border border-border">
                  <Button type="button" variant="ghost" size="icon" className="size-9 rounded-none" onClick={() => clampQuantity(quantity - 1)} aria-label="Decrease quantity">−</Button>
                  <span className="w-10 text-center text-sm">{quantity}</span>
                  <Button type="button" variant="ghost" size="icon" className="size-9 rounded-none" onClick={() => clampQuantity(quantity + 1)} aria-label="Increase quantity">+</Button>
                </div>
              </div>
            )}

            <div className="mt-8 grid gap-3 sm:grid-cols-[1fr_1fr_auto]">
              {outOfStock ? (
                <Button type="button" variant="outline" disabled className="col-span-2 h-12 rounded-none">
                  Out of stock
                </Button>
              ) : (
                <>
                  <Button type="button" variant="outline" className="h-12 rounded-none" onClick={() => addToCart(product.id, quantity)}>
                    <ShoppingBag /> Add to cart
                  </Button>
                  <Button type="button" className="h-12 rounded-none" onClick={() => { addToCart(product.id, quantity); setCartOpen(true); }}>
                    Buy now
                  </Button>
                </>
              )}
              <Button
                type="button"
                variant="outline"
                size="icon"
                className={cn("h-12 w-12 rounded-none", saved && "border-primary bg-primary text-primary-foreground")}
                onClick={() => toggleWishlist(product.id)}
                aria-label={saved ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
              >
                <Heart className={saved ? "fill-current" : ""} />
              </Button>
            </div>
          </div>
        </section>

        {related.length > 0 && (
          <section className="border-t border-border px-5 py-12 sm:px-8 lg:px-10">
            <div className="mx-auto max-w-[1480px]">
              <h2 className="font-display text-3xl text-foreground">You may also like</h2>
              <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {related.map((relatedProduct) => (
                  <ProductCard key={relatedProduct.id} product={relatedProduct} />
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
      <SiteFooter />
    </>
  );
}
