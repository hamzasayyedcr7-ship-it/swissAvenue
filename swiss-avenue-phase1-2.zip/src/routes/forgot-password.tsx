import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";

import { SiteHeader } from "@/components/storefront/site-header";
import { SiteFooter } from "@/components/storefront/site-footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({ meta: [{ title: "Reset password — Swiss Avenue" }] }),
  component: ForgotPasswordPage,
});

function ForgotPasswordPage() {
  const { sendPasswordReset, configured } = useAuth();
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    const { error: resetError } = await sendPasswordReset(email);
    setSubmitting(false);
    if (resetError) {
      setError(resetError);
      return;
    }
    setSent(true);
  }

  return (
    <>
      <SiteHeader />
      <main className="grid min-h-[70vh] place-items-center bg-background px-5 py-16 text-center">
        <div className="w-full max-w-sm">
          {sent ? (
            <>
              <h1 className="font-display text-4xl text-foreground">Check your email</h1>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">
                If an account exists for <strong className="text-foreground">{email}</strong>, a reset link is on its way.
              </p>
              <Button asChild className="mt-7 rounded-none">
                <Link to="/login">Back to login</Link>
              </Button>
            </>
          ) : (
            <>
              <h1 className="font-display text-4xl text-foreground text-left sm:text-center">Reset your password</h1>
              <p className="mt-2 text-left text-sm text-muted-foreground sm:text-center">We'll email you a link to set a new one.</p>

              {!configured && (
                <p className="mt-5 border border-destructive/40 bg-destructive/5 p-3 text-left text-xs text-destructive">
                  Authentication isn't configured yet — set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment.
                </p>
              )}

              <form onSubmit={handleSubmit} className="mt-8 space-y-5 text-left">
                <div className="space-y-1.5">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-none" />
                </div>
                {error && <p className="text-sm text-destructive">{error}</p>}
                <Button type="submit" disabled={submitting || !configured} className="h-11 w-full rounded-none">
                  {submitting ? "Sending…" : "Send reset link"}
                </Button>
              </form>

              <p className="mt-6 text-sm text-muted-foreground">
                <Link to="/login" className="text-primary hover:underline">Back to login</Link>
              </p>
            </>
          )}
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
