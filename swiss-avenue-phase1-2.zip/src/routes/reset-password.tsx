import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";

import { SiteHeader } from "@/components/storefront/site-header";
import { SiteFooter } from "@/components/storefront/site-footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [{ title: "Set a new password — Swiss Avenue" }] }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const { updatePassword, user, loading } = useAuth();
  const navigate = useNavigate();

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);

    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords don't match.");
      return;
    }

    setSubmitting(true);
    const { error: updateError } = await updatePassword(password);
    setSubmitting(false);

    if (updateError) {
      setError(updateError);
      return;
    }
    setDone(true);
    window.setTimeout(() => navigate({ to: "/account" }), 1500);
  }

  return (
    <>
      <SiteHeader />
      <main className="grid min-h-[70vh] place-items-center bg-background px-5 py-16 text-center">
        <div className="w-full max-w-sm text-left">
          <h1 className="font-display text-4xl text-foreground text-center">Set a new password</h1>

          {done ? (
            <p className="mt-5 text-center text-sm text-muted-foreground">Password updated — taking you to your account…</p>
          ) : !loading && !user ? (
            <p className="mt-5 border border-destructive/40 bg-destructive/5 p-3 text-center text-xs text-destructive">
              This reset link is invalid or has expired. Request a new one from the forgot password page.
            </p>
          ) : (
            <form onSubmit={handleSubmit} className="mt-8 space-y-5">
              <div className="space-y-1.5">
                <Label htmlFor="password">New password</Label>
                <Input id="password" type="password" required autoComplete="new-password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} className="rounded-none" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="confirmPassword">Confirm new password</Label>
                <Input id="confirmPassword" type="password" required autoComplete="new-password" minLength={8} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="rounded-none" />
              </div>
              {error && <p className="text-sm text-destructive">{error}</p>}
              <Button type="submit" disabled={submitting} className="h-11 w-full rounded-none">
                {submitting ? "Updating…" : "Update password"}
              </Button>
            </form>
          )}
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
