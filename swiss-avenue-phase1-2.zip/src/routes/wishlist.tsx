import { createFileRoute, Link } from "@tanstack/react-router";
import { ShoppingBag, X } from "lucide-react";

import { SiteHeader } from "@/components/storefront/site-header";
import { SiteFooter } from "@/components/storefront/site-footer";
import { EmptyState } from "@/components/storefront/empty-state";
import { Button } from "@/components/ui/button";
import { formatPrice, getProduct } from "@/lib/products";
import { useStorefront } from "@/lib/storefront";

export const Route = createFileRoute("/wishlist")({
  head: () => ({
    meta: [
      { title: "Wishlist — Swiss Avenue" },
      { name: "description", content: "Fragrances you've saved to revisit or move to your cart." },
    ],
  }),
  component: WishlistPage,
});

function WishlistPage() {
  const { wishlist, toggleWishlist, moveToCart } = useStorefront();
  const items = wishlist.flatMap((productId) => {
    const product = getProduct(productId);
    return product ? [product] : [];
  });

  return (
    <>
      <SiteHeader />
      <main className="bg-background">
        <section className="border-b border-border bg-secondary/40 px-5 py-12 sm:px-8 lg:px-10">
          <div className="mx-auto max-w-[1480px]">
            <p className="eyebrow text-muted-foreground">Saved for later</p>
            <h1 className="mt-3 font-display text-5xl text-foreground sm:text-6xl">Your wishlist</h1>
          </div>
        </section>

        <section className="px-5 py-10 sm:px-8 lg:px-10">
          <div className="mx-auto max-w-[1480px]">
            {items.length === 0 ? (
              <EmptyState title="Your wishlist is empty" copy="Save fragrances you're considering so you can find them again easily." />
            ) : (
              <div className="divide-y divide-border border-y border-border">
                {items.map((product) => {
                  const outOfStock = product.stock <= 0;
                  return (
                    <div key={product.id} className="grid grid-cols-[88px_1fr_auto] items-center gap-4 py-4 sm:grid-cols-[104px_1fr_auto_auto]">
                      <Link to="/products/$productId" params={{ productId: product.id }}>
                        <img src={product.image} alt="" width={1024} height={1280} className="aspect-[4/5] w-full object-cover" />
                      </Link>
                      <div className="min-w-0">
                        <Link to="/products/$productId" params={{ productId: product.id }} className="font-display text-xl leading-none text-foreground hover:text-primary sm:text-2xl">
                          {product.name}
                        </Link>
                        <p className="mt-1 text-xs text-muted-foreground">{product.type} · {product.size}</p>
                        <p className="mt-2 text-sm font-medium text-foreground">{formatPrice(product.price)}</p>
                        {outOfStock && <p className="mt-1 text-xs font-medium text-destructive">Out of stock</p>}
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        className="col-span-2 h-10 rounded-none sm:col-span-1"
                        disabled={outOfStock}
                        onClick={() => moveToCart(product.id)}
                      >
                        <ShoppingBag /> Move to cart
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="hidden text-muted-foreground sm:inline-flex"
                        onClick={() => toggleWishlist(product.id)}
                        aria-label={`Remove ${product.name} from wishlist`}
                      >
                        <X />
                      </Button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
