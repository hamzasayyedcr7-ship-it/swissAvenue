import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

type CartLine = { productId: string; quantity: number };

type StorefrontContextValue = {
  cart: CartLine[];
  wishlist: string[];
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  addToCart: (productId: string, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  setQuantity: (productId: string, quantity: number) => void;
  toggleWishlist: (productId: string) => void;
  moveToCart: (productId: string) => void;
  cartCount: number;
};

const StorefrontContext = createContext<StorefrontContextValue | undefined>(undefined);

export function StorefrontProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      setCart(JSON.parse(localStorage.getItem("swiss-avenue-cart") ?? "[]"));
      setWishlist(JSON.parse(localStorage.getItem("swiss-avenue-wishlist") ?? "[]"));
    } catch {
      setCart([]);
      setWishlist([]);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem("swiss-avenue-cart", JSON.stringify(cart));
  }, [cart, hydrated]);

  useEffect(() => {
    if (hydrated) localStorage.setItem("swiss-avenue-wishlist", JSON.stringify(wishlist));
  }, [wishlist, hydrated]);

  const value = useMemo<StorefrontContextValue>(() => ({
    cart,
    wishlist,
    cartOpen,
    setCartOpen,
    addToCart(productId, quantity = 1) {
      setCart((current) => {
        const existing = current.find((line) => line.productId === productId);
        return existing
          ? current.map((line) => line.productId === productId ? { ...line, quantity: line.quantity + quantity } : line)
          : [...current, { productId, quantity }];
      });
    },
    removeFromCart(productId) {
      setCart((current) => current.filter((line) => line.productId !== productId));
    },
    setQuantity(productId, quantity) {
      if (quantity < 1) {
        setCart((current) => current.filter((line) => line.productId !== productId));
        return;
      }
      setCart((current) => current.map((line) => line.productId === productId ? { ...line, quantity } : line));
    },
    toggleWishlist(productId) {
      setWishlist((current) => current.includes(productId) ? current.filter((id) => id !== productId) : [...current, productId]);
    },
    moveToCart(productId) {
      setCart((current) => current.some((line) => line.productId === productId)
        ? current.map((line) => line.productId === productId ? { ...line, quantity: line.quantity + 1 } : line)
        : [...current, { productId, quantity: 1 }]);
      setWishlist((current) => current.filter((id) => id !== productId));
    },
    cartCount: cart.reduce((sum, line) => sum + line.quantity, 0),
  }), [cart, wishlist, cartOpen, hydrated]);

  return <StorefrontContext.Provider value={value}>{children}</StorefrontContext.Provider>;
}

export function useStorefront() {
  const context = useContext(StorefrontContext);
  if (!context) throw new Error("useStorefront must be used within StorefrontProvider");
  return context;
}