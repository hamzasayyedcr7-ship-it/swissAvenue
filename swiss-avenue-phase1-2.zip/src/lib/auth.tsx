import type { User } from "@supabase/supabase-js";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

import { getSupabaseBrowserClient, isSupabaseConfigured } from "./supabase/client";
import type { Database } from "./supabase/types";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];

type AuthContextValue = {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  /** False until VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY are set. */
  configured: boolean;
  signUp: (input: {
    email: string;
    password: string;
    fullName: string;
    phone: string;
  }) => Promise<{ error: string | null; needsEmailConfirmation: boolean }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  sendPasswordReset: (email: string) => Promise<{ error: string | null }>;
  updatePassword: (password: string) => Promise<{ error: string | null }>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const configured = isSupabaseConfigured();
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(configured);

  // Track the session. onAuthStateChange fires once immediately with the
  // current session (or null), so we don't need a separate getSession call.
  useEffect(() => {
    if (!configured) {
      setLoading(false);
      return;
    }
    const supabase = getSupabaseBrowserClient();
    const { data: subscription } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });
    return () => subscription.subscription.unsubscribe();
  }, [configured]);

  useEffect(() => {
    if (!configured || !user) {
      setProfile(null);
      return;
    }
    let cancelled = false;
    getSupabaseBrowserClient()
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single()
      .then(({ data }) => {
        if (!cancelled) setProfile(data ?? null);
      });
    return () => {
      cancelled = true;
    };
  }, [configured, user]);

  async function refreshProfile() {
    if (!configured || !user) return;
    const { data } = await getSupabaseBrowserClient().from("profiles").select("*").eq("id", user.id).single();
    setProfile(data ?? null);
  }

  async function signUp({ email, password, fullName, phone }: { email: string; password: string; fullName: string; phone: string }) {
    const { data, error } = await getSupabaseBrowserClient().auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName, phone } },
    });
    return { error: error?.message ?? null, needsEmailConfirmation: !error && !data.session };
  }

  async function signIn(email: string, password: string) {
    const { error } = await getSupabaseBrowserClient().auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  }

  async function signOut() {
    await getSupabaseBrowserClient().auth.signOut();
  }

  async function sendPasswordReset(email: string) {
    const redirectTo = typeof window !== "undefined" ? `${window.location.origin}/reset-password` : undefined;
    const { error } = await getSupabaseBrowserClient().auth.resetPasswordForEmail(email, { redirectTo });
    return { error: error?.message ?? null };
  }

  async function updatePassword(password: string) {
    const { error } = await getSupabaseBrowserClient().auth.updateUser({ password });
    return { error: error?.message ?? null };
  }

  const value: AuthContextValue = {
    user,
    profile,
    loading,
    configured,
    signUp,
    signIn,
    signOut,
    sendPasswordReset,
    updatePassword,
    refreshProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
}
