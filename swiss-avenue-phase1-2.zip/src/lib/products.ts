import blueGlass from "@/assets/perfume-blue-glass.jpg";
import crystalOval from "@/assets/perfume-crystal-oval.jpg";
import frostedTall from "@/assets/perfume-frosted-tall.jpg";
import facetedIce from "@/assets/perfume-faceted-ice.jpg";

export const PRODUCT_TYPES = [
  "Eau de Parfum",
  "Eau de Toilette",
  "Oud",
  "Attar",
  "Floral",
  "Fresh",
  "Woody",
  "Unisex",
] as const;

export type ProductType = (typeof PRODUCT_TYPES)[number];

export type Product = {
  id: string;
  name: string;
  type: ProductType;
  price: number;
  mrp: number;
  discountPercent: number;
  size: string;
  notes: string;
  description: string;
  image: string;
  rating: number;
  reviewCount: number;
  stock: number;
  createdAt: number;
};

const names = [
  "Azure Veil", "Celestial Iris", "Riviera Mist", "Silken Neroli", "Blue Hour", "Moonlit Fig",
  "Aegean Air", "Crystal Saffron", "White Cedar", "Coastal Bloom", "Cloud Atlas", "Silver Rose",
  "Quiet Current", "Alpine Musk", "Luminous Oud", "Morning Vetiver", "Porcelain Tea", "Sea of Jasmine",
  "Pale Ember", "Rainwashed Linen", "Skyward Amber", "Infinite Peony", "Cypress Light", "Sapphire Woods",
  "Cashmere Tide", "Frosted Bergamot", "Still Water", "Orchid Horizon", "Aerial Tonka", "Mistral Leather",
  "Nimbus Rose", "Glacier Incense", "Blue Cypress", "Cotton Santal", "Maritime Iris", "Daybreak Oud",
  "Opaline Musk", "Serein", "Northern Neroli", "Ice Petal", "Azure Resin", "Lucent Amber",
  "White Horizon", "Calm Vetiver", "Skyline Fig", "Cobalt Tea", "Pearl Woods", "Ethereal Saffron",
  "Solstice Bloom", "Glasshouse Moss", "Blue Magnolia", "Silent Coast", "Aqua Suede", "Halo Cedar",
];

const noteSets = [
  "Bergamot · White tea · Cedar",
  "Iris · Violet leaf · Musk",
  "Neroli · Sea salt · Vetiver",
  "Rose · Saffron · Sandalwood",
  "Fig leaf · Cypress · Amber",
  "Jasmine · Pear · Cashmere wood",
  "Lavender · Tonka · Soft leather",
  "Mandarin · Peony · White musk",
  "Incense · Cardamom · Oud",
];

const descriptions = [
  "A poised composition that opens with clarity before settling into a soft, quietly persistent trail.",
  "Airy florals and polished woods meet in a modern signature designed for effortless everyday wear.",
  "Fresh at first impression, then gently textured with warm notes that remain close to the skin.",
  "A refined study in contrast, balancing luminous top notes with a smooth and memorable dry-down.",
  "Clean, expressive and composed with a restrained elegance suited to both day and evening.",
  "A contemporary fragrance with graceful projection, nuanced depth and an assured finish.",
];

const images = [blueGlass, crystalOval, frostedTall, facetedIce];

export const products: Product[] = names.map((name, index) => {
  const price = 1899 + (index % 9) * 350 + Math.floor(index / 9) * 125;
  // Roughly every third product carries a discount off a higher MRP.
  const mrp = index % 3 === 0 ? price + 300 + (index % 5) * 120 : price;
  const discountPercent = mrp > price ? Math.round((1 - price / mrp) * 100) : 0;
  // A handful of products are deliberately out of stock to exercise that state.
  const stock = index % 11 === 0 ? 0 : 3 + ((index * 5) % 24);

  return {
    id: name.toLowerCase().replace(/\s+/g, "-"),
    name,
    type: PRODUCT_TYPES[index % PRODUCT_TYPES.length] ?? "Eau de Parfum",
    price,
    mrp,
    discountPercent,
    size: index % 3 === 0 ? "100 ml" : index % 3 === 1 ? "75 ml" : "50 ml",
    notes: noteSets[index % noteSets.length] ?? noteSets[0] ?? "Bergamot · White tea · Cedar",
    description: descriptions[index % descriptions.length] ?? descriptions[0] ?? "A refined modern fragrance.",
    image: images[index % images.length] ?? blueGlass,
    rating: Math.round((3.8 + ((index * 7) % 12) / 10) * 10) / 10,
    reviewCount: 18 + ((index * 13) % 240),
    stock,
    createdAt: names.length - index,
  };
});

export function getProduct(productId: string) {
  return products.find((product) => product.id === productId);
}

export function formatPrice(price: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(price);
}