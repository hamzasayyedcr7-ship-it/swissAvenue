import { createClient, type SupabaseClient } from "@supabase/supabase-js";

import type { Database } from "./types";

// IMPORTANT: this file must only ever be imported from server-side code
// (TanStack Start server functions, i.e. handlers created with
// `createServerFn`). It reads secrets via plain `process.env`, which Vite
// does not inline into the client bundle (unlike `import.meta.env.VITE_*`),
// so importing this from a component will fail loudly with "process is not
// defined" in the browser rather than silently shipping a secret.
//
// The service role key bypasses Row Level Security entirely — every query
// made with this client is trusted. That's exactly why it's used for order
// creation, payment verification, and admin writes: those flows recompute
// and validate everything server-side rather than trusting client input.

let adminClient: SupabaseClient<Database> | undefined;

export function getSupabaseServiceRoleClient() {
  const url = process.env.VITE_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceRoleKey) {
    throw new Error(
      "Supabase service role is not configured. Set VITE_SUPABASE_URL and " +
        "SUPABASE_SERVICE_ROLE_KEY as server environment variables (see .env.example). " +
        "Never prefix the service role key with VITE_ — that would expose it to the browser.",
    );
  }

  adminClient ??= createClient<Database>(url, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return adminClient;
}
