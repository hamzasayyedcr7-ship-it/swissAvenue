import { createClient, type SupabaseClient } from "@supabase/supabase-js";

import type { Database } from "./types";

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let browserClient: SupabaseClient<Database> | undefined;

/**
 * Lazily-created Supabase client for use in browser code (components, the
 * auth context, etc). Only ever holds the anon key — every table it can
 * reach is governed by the RLS policies in supabase/migrations/0001_init.sql,
 * so this key being public is expected and safe.
 */
export function getSupabaseBrowserClient() {
  if (!url || !anonKey) {
    throw new Error(
      "Supabase is not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY " +
        "in your .env file (see .env.example) and restart the dev server.",
    );
  }
  browserClient ??= createClient<Database>(url, anonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
  return browserClient;
}

export function isSupabaseConfigured() {
  return Boolean(url && anonKey);
}
