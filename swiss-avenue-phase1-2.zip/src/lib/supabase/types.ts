// Hand-written to match supabase/migrations/0001_init.sql.
// Once you have a live Supabase project, replace this file with the real
// generated types:
//
//   npx supabase gen types typescript --project-id <ref> > src/lib/supabase/types.ts
//
// Keeping it here in the meantime gives autocomplete + type-checking on
// every query without requiring network access to generate it.

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "processing"
  | "shipped"
  | "out_for_delivery"
  | "delivered"
  | "cancelled"
  | "refunded";

export type PaymentStatus = "pending" | "paid" | "failed" | "refunded";
export type PaymentMethod = "razorpay" | "cod";
export type PaymentProviderStatus = "created" | "authorized" | "captured" | "failed" | "refunded";
export type UserRole = "customer" | "admin";
export type CouponType = "percent" | "fixed";

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string | null;
          phone: string | null;
          role: UserRole;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["profiles"]["Row"]> & { id: string };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Row"]>;
      };
      categories: {
        Row: {
          id: string;
          name: string;
          slug: string;
          image_url: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["categories"]["Row"]> & { name: string; slug: string };
        Update: Partial<Database["public"]["Tables"]["categories"]["Row"]>;
      };
      products: {
        Row: {
          id: string;
          category_id: string | null;
          name: string;
          slug: string;
          type: string | null;
          size: string | null;
          notes: string | null;
          description: string | null;
          details: string | null;
          price: number;
          mrp: number;
          stock: number;
          rating: number;
          review_count: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["products"]["Row"]> & { name: string; slug: string; price: number; mrp: number };
        Update: Partial<Database["public"]["Tables"]["products"]["Row"]>;
      };
      product_images: {
        Row: { id: string; product_id: string; url: string; alt_text: string | null; position: number };
        Insert: Partial<Database["public"]["Tables"]["product_images"]["Row"]> & { product_id: string; url: string };
        Update: Partial<Database["public"]["Tables"]["product_images"]["Row"]>;
      };
      product_variants: {
        Row: { id: string; product_id: string; label: string; price_override: number | null; stock: number; sku: string | null };
        Insert: Partial<Database["public"]["Tables"]["product_variants"]["Row"]> & { product_id: string; label: string };
        Update: Partial<Database["public"]["Tables"]["product_variants"]["Row"]>;
      };
      addresses: {
        Row: {
          id: string;
          user_id: string;
          full_name: string;
          phone: string;
          line1: string;
          line2: string | null;
          city: string;
          state: string;
          postal_code: string;
          country: string;
          is_default: boolean;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["addresses"]["Row"]> & {
          user_id: string;
          full_name: string;
          phone: string;
          line1: string;
          city: string;
          state: string;
          postal_code: string;
        };
        Update: Partial<Database["public"]["Tables"]["addresses"]["Row"]>;
      };
      cart_items: {
        Row: { id: string; user_id: string; product_id: string; variant_id: string | null; quantity: number; created_at: string };
        Insert: Partial<Database["public"]["Tables"]["cart_items"]["Row"]> & { user_id: string; product_id: string; quantity: number };
        Update: Partial<Database["public"]["Tables"]["cart_items"]["Row"]>;
      };
      wishlist_items: {
        Row: { id: string; user_id: string; product_id: string; created_at: string };
        Insert: Partial<Database["public"]["Tables"]["wishlist_items"]["Row"]> & { user_id: string; product_id: string };
        Update: Partial<Database["public"]["Tables"]["wishlist_items"]["Row"]>;
      };
      coupons: {
        Row: {
          id: string;
          code: string;
          type: CouponType;
          value: number;
          min_order_amount: number;
          max_uses: number | null;
          used_count: number;
          expires_at: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["coupons"]["Row"]> & { code: string; type: CouponType; value: number };
        Update: Partial<Database["public"]["Tables"]["coupons"]["Row"]>;
      };
      orders: {
        Row: {
          id: string;
          order_number: string;
          user_id: string | null;
          status: OrderStatus;
          payment_status: PaymentStatus;
          payment_method: PaymentMethod;
          subtotal: number;
          discount_total: number;
          shipping_total: number;
          tax_total: number;
          total: number;
          coupon_code: string | null;
          shipping_name: string;
          shipping_phone: string;
          shipping_line1: string;
          shipping_line2: string | null;
          shipping_city: string;
          shipping_state: string;
          shipping_postal_code: string;
          shipping_country: string;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["orders"]["Row"]> & {
          subtotal: number;
          total: number;
          shipping_name: string;
          shipping_phone: string;
          shipping_line1: string;
          shipping_city: string;
          shipping_state: string;
          shipping_postal_code: string;
        };
        Update: Partial<Database["public"]["Tables"]["orders"]["Row"]>;
      };
      order_items: {
        Row: {
          id: string;
          order_id: string;
          product_id: string | null;
          product_name: string;
          variant_label: string | null;
          unit_price: number;
          quantity: number;
          line_total: number;
        };
        Insert: Partial<Database["public"]["Tables"]["order_items"]["Row"]> & {
          order_id: string;
          product_name: string;
          unit_price: number;
          quantity: number;
          line_total: number;
        };
        Update: Partial<Database["public"]["Tables"]["order_items"]["Row"]>;
      };
      payments: {
        Row: {
          id: string;
          order_id: string;
          provider: PaymentMethod;
          provider_order_id: string | null;
          provider_payment_id: string | null;
          provider_signature: string | null;
          status: PaymentProviderStatus;
          amount: number;
          raw_payload: Record<string, unknown> | null;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["payments"]["Row"]> & { order_id: string; amount: number };
        Update: Partial<Database["public"]["Tables"]["payments"]["Row"]>;
      };
      reviews: {
        Row: {
          id: string;
          product_id: string;
          user_id: string | null;
          rating: number;
          title: string | null;
          body: string | null;
          is_approved: boolean;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["reviews"]["Row"]> & { product_id: string; rating: number };
        Update: Partial<Database["public"]["Tables"]["reviews"]["Row"]>;
      };
      contact_messages: {
        Row: { id: string; name: string; email: string | null; phone: string | null; message: string; created_at: string };
        Insert: Partial<Database["public"]["Tables"]["contact_messages"]["Row"]> & { name: string; message: string };
        Update: Partial<Database["public"]["Tables"]["contact_messages"]["Row"]>;
      };
    };
  };
}
