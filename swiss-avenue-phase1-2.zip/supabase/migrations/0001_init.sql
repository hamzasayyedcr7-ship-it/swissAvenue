-- Swiss Avenue — Phase 2 schema
-- Run this against a fresh Supabase project (SQL Editor, or `supabase db push`).
-- Written to be idempotent-ish for local iteration (guards with IF NOT EXISTS
-- where practical), but treat it as a first migration on a clean database.

create extension if not exists "pgcrypto";

-- ============================================================================
-- PROFILES — one row per auth.users row. Role drives all admin RLS checks.
-- ============================================================================
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'customer' check (role in ('customer', 'admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Auto-create a profile row whenever someone signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (
    new.id,
    new.raw_user_meta_data ->> 'full_name',
    new.raw_user_meta_data ->> 'phone'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Helper used throughout RLS policies below. SECURITY DEFINER so it can read
-- profiles even under a caller whose own profile-select policy would
-- otherwise recurse into itself.
create or replace function public.is_admin()
returns boolean
language sql
security definer set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$;

-- ============================================================================
-- CATALOG — categories, products, images, variants
-- ============================================================================
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories (id) on delete set null,
  name text not null,
  slug text not null unique,
  type text,
  size text,
  notes text,
  description text,
  details text,
  price numeric(10, 2) not null check (price >= 0),
  mrp numeric(10, 2) not null check (mrp >= 0),
  stock integer not null default 0 check (stock >= 0),
  rating numeric(2, 1) not null default 0,
  review_count integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists products_category_id_idx on public.products (category_id);
create index if not exists products_is_active_idx on public.products (is_active);

create table if not exists public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products (id) on delete cascade,
  url text not null,
  alt_text text,
  position integer not null default 0
);

create index if not exists product_images_product_id_idx on public.product_images (product_id);

create table if not exists public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products (id) on delete cascade,
  label text not null,
  price_override numeric(10, 2),
  stock integer not null default 0 check (stock >= 0),
  sku text
);

create index if not exists product_variants_product_id_idx on public.product_variants (product_id);

-- ============================================================================
-- ADDRESSES
-- ============================================================================
create table if not exists public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  full_name text not null,
  phone text not null,
  line1 text not null,
  line2 text,
  city text not null,
  state text not null,
  postal_code text not null,
  country text not null default 'India',
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists addresses_user_id_idx on public.addresses (user_id);

-- ============================================================================
-- CART + WISHLIST — DB-backed once a customer is signed in. The storefront
-- keeps using localStorage for guests and syncs into these tables on login
-- (see src/lib/storefront.tsx in a later pass).
-- ============================================================================
create table if not exists public.cart_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  product_id uuid not null references public.products (id) on delete cascade,
  variant_id uuid references public.product_variants (id) on delete set null,
  quantity integer not null check (quantity > 0),
  created_at timestamptz not null default now(),
  unique (user_id, product_id, variant_id)
);

create table if not exists public.wishlist_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  product_id uuid not null references public.products (id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, product_id)
);

-- ============================================================================
-- COUPONS
-- ============================================================================
create table if not exists public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  type text not null check (type in ('percent', 'fixed')),
  value numeric(10, 2) not null check (value >= 0),
  min_order_amount numeric(10, 2) not null default 0,
  max_uses integer,
  used_count integer not null default 0,
  expires_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ============================================================================
-- ORDERS — always written by a trusted server function using the service
-- role key, never inserted directly by client code. RLS below intentionally
-- has no client-facing insert/update policy.
-- ============================================================================
create sequence if not exists public.order_number_seq start 1000;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('SA-' || nextval('public.order_number_seq')::text),
  user_id uuid references public.profiles (id) on delete set null,
  status text not null default 'pending'
    check (status in ('pending', 'confirmed', 'processing', 'shipped', 'out_for_delivery', 'delivered', 'cancelled', 'refunded')),
  payment_status text not null default 'pending'
    check (payment_status in ('pending', 'paid', 'failed', 'refunded')),
  payment_method text not null default 'cod' check (payment_method in ('razorpay', 'cod')),
  subtotal numeric(10, 2) not null,
  discount_total numeric(10, 2) not null default 0,
  shipping_total numeric(10, 2) not null default 0,
  tax_total numeric(10, 2) not null default 0,
  total numeric(10, 2) not null,
  coupon_code text,
  shipping_name text not null,
  shipping_phone text not null,
  shipping_line1 text not null,
  shipping_line2 text,
  shipping_city text not null,
  shipping_state text not null,
  shipping_postal_code text not null,
  shipping_country text not null default 'India',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists orders_user_id_idx on public.orders (user_id);
create index if not exists orders_status_idx on public.orders (status);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders (id) on delete cascade,
  product_id uuid references public.products (id) on delete set null,
  product_name text not null,
  variant_label text,
  unit_price numeric(10, 2) not null,
  quantity integer not null check (quantity > 0),
  line_total numeric(10, 2) not null
);

create index if not exists order_items_order_id_idx on public.order_items (order_id);

-- ============================================================================
-- PAYMENTS — one row per gateway attempt. The unique constraint on
-- (provider, provider_payment_id) is what makes webhook replays a no-op.
-- ============================================================================
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders (id) on delete cascade,
  provider text not null default 'razorpay' check (provider in ('razorpay', 'cod')),
  provider_order_id text,
  provider_payment_id text,
  provider_signature text,
  status text not null default 'created' check (status in ('created', 'authorized', 'captured', 'failed', 'refunded')),
  amount numeric(10, 2) not null,
  raw_payload jsonb,
  created_at timestamptz not null default now(),
  unique (provider, provider_payment_id)
);

create index if not exists payments_order_id_idx on public.payments (order_id);

-- ============================================================================
-- REVIEWS
-- ============================================================================
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products (id) on delete cascade,
  user_id uuid references public.profiles (id) on delete set null,
  rating integer not null check (rating between 1 and 5),
  title text,
  body text,
  is_approved boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists reviews_product_id_idx on public.reviews (product_id);

-- ============================================================================
-- CONTACT MESSAGES
-- ============================================================================
create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text,
  phone text,
  message text not null,
  created_at timestamptz not null default now()
);

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.product_variants enable row level security;
alter table public.addresses enable row level security;
alter table public.cart_items enable row level security;
alter table public.wishlist_items enable row level security;
alter table public.coupons enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.reviews enable row level security;
alter table public.contact_messages enable row level security;

-- profiles: users see/update their own row; admins see everyone.
create policy "profiles_select_own_or_admin" on public.profiles
  for select using (auth.uid() = id or public.is_admin());
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id);
create policy "profiles_admin_manage" on public.profiles
  for all using (public.is_admin()) with check (public.is_admin());

-- categories / products / images / variants: public reads active rows,
-- admins have full read/write regardless of active state.
create policy "categories_public_read" on public.categories
  for select using (is_active or public.is_admin());
create policy "categories_admin_write" on public.categories
  for all using (public.is_admin()) with check (public.is_admin());

create policy "products_public_read" on public.products
  for select using (is_active or public.is_admin());
create policy "products_admin_write" on public.products
  for all using (public.is_admin()) with check (public.is_admin());

create policy "product_images_public_read" on public.product_images
  for select using (true);
create policy "product_images_admin_write" on public.product_images
  for all using (public.is_admin()) with check (public.is_admin());

create policy "product_variants_public_read" on public.product_variants
  for select using (true);
create policy "product_variants_admin_write" on public.product_variants
  for all using (public.is_admin()) with check (public.is_admin());

-- addresses: strictly owner + admin.
create policy "addresses_owner" on public.addresses
  for all using (auth.uid() = user_id or public.is_admin())
  with check (auth.uid() = user_id or public.is_admin());

-- cart / wishlist: strictly owner.
create policy "cart_items_owner" on public.cart_items
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "wishlist_items_owner" on public.wishlist_items
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- coupons: anyone can read active coupons (needed to validate a code at
-- checkout); only admins can create/edit/deactivate.
create policy "coupons_public_read_active" on public.coupons
  for select using (is_active or public.is_admin());
create policy "coupons_admin_write" on public.coupons
  for all using (public.is_admin()) with check (public.is_admin());

-- orders / order_items: customers read their own; admins read/manage all.
-- No insert/update policy for plain authenticated users — orders are only
-- ever written by the service-role key from a server function, after the
-- backend recalculates totals and validates stock itself.
create policy "orders_owner_or_admin_read" on public.orders
  for select using (auth.uid() = user_id or public.is_admin());
create policy "orders_admin_update" on public.orders
  for update using (public.is_admin()) with check (public.is_admin());

create policy "order_items_owner_or_admin_read" on public.order_items
  for select using (
    exists (
      select 1 from public.orders o
      where o.id = order_items.order_id
        and (o.user_id = auth.uid() or public.is_admin())
    )
  );

-- payments: never exposed to plain clients beyond their own order's rows;
-- writes are service-role only (webhook / server function).
create policy "payments_owner_or_admin_read" on public.payments
  for select using (
    exists (
      select 1 from public.orders o
      where o.id = payments.order_id
        and (o.user_id = auth.uid() or public.is_admin())
    )
  );

-- reviews: public reads approved reviews; signed-in users can write their
-- own; admins can moderate.
create policy "reviews_public_read_approved" on public.reviews
  for select using (is_approved or public.is_admin() or auth.uid() = user_id);
create policy "reviews_owner_insert" on public.reviews
  for insert with check (auth.uid() = user_id);
create policy "reviews_owner_update" on public.reviews
  for update using (auth.uid() = user_id or public.is_admin());
create policy "reviews_admin_delete" on public.reviews
  for delete using (public.is_admin());

-- contact messages: anyone (including anonymous visitors) can submit one;
-- only admins can read them back.
create policy "contact_messages_public_insert" on public.contact_messages
  for insert with check (true);
create policy "contact_messages_admin_read" on public.contact_messages
  for select using (public.is_admin());

-- ============================================================================
-- First admin account
-- ============================================================================
-- Sign up normally through the storefront first (Sign Up page), then run:
--
--   update public.profiles set role = 'admin' where id =
--     (select id from auth.users where email = 'admin@example.com');
--
-- See README/setup docs for the full walkthrough.
